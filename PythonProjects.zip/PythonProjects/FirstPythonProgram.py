print("Welcome to Python programming !!!")
x =10
if(x==10):
    print (x)
Garage = "Ferrari,Mustang,Porsche"
for eachcar in Garage:
    print(eachcar)