for b in range(1,12):
    if(b%2==0):
        print("Input {0} is an even number".format(b))

#from input
even=int(input("Input value:"))
if(even%2==0):
    print("even number")
else:
    print("odd number")