a=int(input("pls input:"))
while(a>10):
    a +=1
    print(a)
    if(a==5):
        break
