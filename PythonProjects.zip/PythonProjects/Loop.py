print("Provide the input:")
x=input()
if(x.__gt__(10)):
    print("Input {0} is greater than 10".format(x))
else:
    print("Input {0} is less than 10".format(x))

b=int(input("Input Integer value:"))
if(b.__eq__(5)):
    print("Equals")
