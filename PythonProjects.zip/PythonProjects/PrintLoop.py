print(3e8)

for val in "string":
    if val=="i":
        print(val)
        break
