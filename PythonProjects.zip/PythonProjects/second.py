#This is a single line comment
a=10
b=10.5
c="Hello"
d=["Bike","Car","Bus"]
e=112334587867564867894654
f=True
g = {"Java","Python"}
"""
multiline comments
Prints the
value
and its data type
"""
print ((a), type(a),(b), type(b),(c), type(c),(d), type(d),(e), type(e),(f), type(f),(g), type(g))
'''
end of 
multiline comments
'''

