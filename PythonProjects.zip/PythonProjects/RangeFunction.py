d=[4,5,6,7,8,9,10,12]
e=d[2:6]
print(e)
for dd in range(1, 100):
   dd += dd
   print(dd)