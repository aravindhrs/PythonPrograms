addvar=3
addvar +=5
print(addvar)
print("----------")
subassign= 6
subassign -=3
print(subassign)
print("----------")
divassign = 56/2
print(divassign)
print("----------")
floordiv=24.5/2
print(floordiv)
print("----------")
floordiv1=29.5//2
print("Floor division:")
print(floordiv1)
print("----------")
a,b,c=10,20,30
print(c,b,a)
print("----------")
str1="this is a strimng \' the crow \t is a bird \' \n welcome"
print(str1.capitalize())
print("----------")
str2="HelloPython"
print(str2[0])
print("----------")
ex1 = str2[:3]
print(ex1)
print("----------")
ex2 = str2[3:]
print(ex2)
print("----------")
ex3 = str2[2:3]
print(ex3)
print("----------")
c='oslo'
print(c.capitalize())
print("----------")
d=b'some bytes'
d.split(d)
print(d.split())
print(d)
print("----------")
#strings

strsplit = "hello".replace('e','o')
print(strsplit)
print("----------")
print("hello34".isalnum())
print("hello".isalpha())
print("some,csv,values".split(","))
print("----------")
name="sharon"
age=60
print("this is {0} and this is {1}".format(name,age))
print("this is {0} and this is {1}".format(name,age).upper())
print("this is {0} and this is {1}".format(name,age).lower())
print("----------")
#to print binary value